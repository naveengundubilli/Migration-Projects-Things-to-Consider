Swing → JavaFX or Web Migration — Lucid Diagram Pack

This folder contains CSV edge lists you can import into Lucid to generate diagrams quickly.

How to use in Lucid:
1) Open Lucid (Lucidchart or Lucidspark) → Create a Blank Document.
2) Click File → Import Data (or Insert → Data → Import Data). Choose CSV.
3) Select one of the CSV files, e.g., `strangler_edges.csv`.
4) Map columns:
   - From → Source node
   - To → Target node
   - Label → Line label (optional; can be shown as text on the connector)
5) Choose a diagram type:
   - Use "Flowchart" or "Concept Map" style. Enable auto-layout for readability.
   - After import, select all → Arrange → Auto Layout (Hierarchical).
6) Style:
   - Group nodes into containers (e.g., UI, Domain, Adapters) for clarity.
   - Use shape libraries (flowchart, UML, or C4) per your preference.

Files:
- strangler_edges.csv            → Strangler Fig Migration
- threading_edges.csv            → Threading Model Shift
- ports_adapters_edges.csv       → Hexagonal (Ports & Adapters)
- javafx_mvvm_edges.csv          → JavaFX MVVM Binding
- web_target_edges.csv           → Web Target Architecture
- auth_flow_edges.csv            → AuthN/AuthZ Flow (OIDC/RBAC)
- delivery_pipelines_edges.csv   → CI/CD & Packaging
- reporting_edges.csv            → Reporting & Printing Replacement

Tip:
- You can duplicate the page and import multiple CSVs into separate pages to keep each view focused.
- Add swimlanes or containers titled: "UI", "Ports", "Domain", "Adapters", "Data Stores", "Telemetry".